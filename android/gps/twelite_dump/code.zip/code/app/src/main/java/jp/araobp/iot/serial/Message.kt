package jp.araobp.iot.serial

data class Message(var message: String = "")
